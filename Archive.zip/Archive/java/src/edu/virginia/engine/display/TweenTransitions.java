package edu.virginia.engine.display;

public class TweenTransitions {
	
	public void ease(double percentDone) {
		
	}
	
	public void fade(double percentDone) {
		
	}
	
	public void coinAnimation(double percentDone) {
		
	}

}
