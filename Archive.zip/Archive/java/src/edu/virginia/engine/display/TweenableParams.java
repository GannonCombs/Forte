package edu.virginia.engine.display;

public enum TweenableParams {
	X, Y, SCALE_X, SCALE_Y, ALPHA, ROTATION; 
}
