arrow keys control the movement of the character, up key is jump and jump generates a bass sound.

A and S keys throw a music note to left or right and when the music note hits the enemy, the character teleports to the enemy and the enemy disappears while generating a piano note. Colliding with an enemy also kills the enemy and generates a piano note. The enemy respawns after being killed.

A and S keys generate another bass note.

Z and X are quick downward dash. 

Background drum music loops forever.
