package edu.virginia.engine.events;

public interface IEventListener {
	public void handleEvent(Event event);
}
